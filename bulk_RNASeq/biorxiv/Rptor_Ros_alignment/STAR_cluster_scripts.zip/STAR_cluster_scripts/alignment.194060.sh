#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.194060
#SBATCH --output=s.194060.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194060
echo $(date) $(hostname) > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194060/alignment.194060.job.log
module load samtools

samtools --version > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194060/samtools.version
/nfs/scistore16/hippegrp/fpauler/programs/STAR_279a --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif \
        --outFilterIntronMotifs RemoveNoncanonical \
        --outFilterScoreMinOverLread 0.22 --outFilterMatchNminOverLread 0.22 \
        --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
        --outFileNamePrefix /localhome/fpauler/STAR.194060. --readFilesCommand zcat \
        --genomeDir /nfs/scistore16/hippegrp/fpauler/STAR_index_with_M27/ \
        --readFilesIn /nfs/scistore16/hippegrp/fpauler/bam_files/raw_BAM_files/194060_S108_R1_001.fastq.gz 2> /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194060/STAR.194060.err > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194060/STAR.194060.log

cp -R /localhome/fpauler/STAR.194060.* /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194060/.
rm /localhome/fpauler/STAR.194060.* -r 
rm /localhome/fpauler/PIPE*194060
