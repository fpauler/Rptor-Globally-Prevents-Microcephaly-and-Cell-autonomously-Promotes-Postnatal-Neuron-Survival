#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.194067
#SBATCH --output=s.194067.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194067
echo $(date) $(hostname) > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194067/alignment.194067.job.log
module load samtools

samtools --version > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194067/samtools.version
/nfs/scistore16/hippegrp/fpauler/programs/STAR_279a --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif \
        --outFilterIntronMotifs RemoveNoncanonical \
        --outFilterScoreMinOverLread 0.22 --outFilterMatchNminOverLread 0.22 \
        --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
        --outFileNamePrefix /localhome/fpauler/STAR.194067. --readFilesCommand zcat \
        --genomeDir /nfs/scistore16/hippegrp/fpauler/STAR_index_with_M27/ \
        --readFilesIn /nfs/scistore16/hippegrp/fpauler/bam_files/raw_BAM_files/194067_S101_R1_001.fastq.gz 2> /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194067/STAR.194067.err > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194067/STAR.194067.log

cp -R /localhome/fpauler/STAR.194067.* /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194067/.
rm /localhome/fpauler/STAR.194067.* -r 
rm /localhome/fpauler/PIPE*194067
