#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.194071
#SBATCH --output=s.194071.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194071
echo $(date) $(hostname) > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194071/alignment.194071.job.log
module load samtools

samtools --version > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194071/samtools.version
/nfs/scistore16/hippegrp/fpauler/programs/STAR_279a --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif \
        --outFilterIntronMotifs RemoveNoncanonical \
        --outFilterScoreMinOverLread 0.22 --outFilterMatchNminOverLread 0.22 \
        --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
        --outFileNamePrefix /localhome/fpauler/STAR.194071. --readFilesCommand zcat \
        --genomeDir /nfs/scistore16/hippegrp/fpauler/STAR_index_with_M27/ \
        --readFilesIn /nfs/scistore16/hippegrp/fpauler/bam_files/raw_BAM_files/194071_S97_R1_001.fastq.gz 2> /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194071/STAR.194071.err > /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194071/STAR.194071.log

cp -R /localhome/fpauler/STAR.194071.* /nfs/scistore16/hippegrp/fpauler/bam_files/alignment.194071/.
rm /localhome/fpauler/STAR.194071.* -r 
rm /localhome/fpauler/PIPE*194071
