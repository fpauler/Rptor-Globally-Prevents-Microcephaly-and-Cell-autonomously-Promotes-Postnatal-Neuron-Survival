#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77875
#SBATCH --output=s.77875.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/alignment.77875.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/samtools.version
samtools merge -@2 /localhome/fpauler/77875.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77875.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77875.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77875.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77875.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77875.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/merging.log

mkfifo /localhome/fpauler/PIPE.77875
bamToFastq -i /localhome/fpauler/77875.merged.bam -fq /localhome/fpauler/PIPE.77875 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/samtofastq.77875.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/samtofastq.77875.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77875. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77875 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/STAR.77875.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/STAR.77875.log

cp -R /localhome/fpauler/STAR.77875.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77875/.
rm /localhome/fpauler/STAR.77875.* -r 
rm /localhome/fpauler/PIPE*77875
rm /localhome/fpauler/77875.merged.bam
