#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77850
#SBATCH --output=s.77850.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/alignment.77850.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/samtools.version
samtools merge -@2 /localhome/fpauler/77850.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77850.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77850.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77850.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77850.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77850.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/merging.log

mkfifo /localhome/fpauler/PIPE.77850
bamToFastq -i /localhome/fpauler/77850.merged.bam -fq /localhome/fpauler/PIPE.77850 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/samtofastq.77850.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/samtofastq.77850.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77850. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77850 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/STAR.77850.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/STAR.77850.log

cp -R /localhome/fpauler/STAR.77850.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77850/.
rm /localhome/fpauler/STAR.77850.* -r 
rm /localhome/fpauler/PIPE*77850
rm /localhome/fpauler/77850.merged.bam
