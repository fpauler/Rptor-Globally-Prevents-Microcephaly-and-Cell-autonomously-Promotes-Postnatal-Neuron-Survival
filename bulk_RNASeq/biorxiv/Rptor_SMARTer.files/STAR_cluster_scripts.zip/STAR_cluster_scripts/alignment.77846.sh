#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77846
#SBATCH --output=s.77846.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/alignment.77846.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/samtools.version
samtools merge -@2 /localhome/fpauler/77846.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77846.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77846.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77846.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77846.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77846.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/merging.log

mkfifo /localhome/fpauler/PIPE.77846
bamToFastq -i /localhome/fpauler/77846.merged.bam -fq /localhome/fpauler/PIPE.77846 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/samtofastq.77846.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/samtofastq.77846.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77846. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77846 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/STAR.77846.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/STAR.77846.log

cp -R /localhome/fpauler/STAR.77846.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77846/.
rm /localhome/fpauler/STAR.77846.* -r 
rm /localhome/fpauler/PIPE*77846
rm /localhome/fpauler/77846.merged.bam
