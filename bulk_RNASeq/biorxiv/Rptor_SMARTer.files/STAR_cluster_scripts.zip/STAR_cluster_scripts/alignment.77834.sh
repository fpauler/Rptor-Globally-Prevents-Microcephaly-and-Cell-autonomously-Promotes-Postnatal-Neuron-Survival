#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77834
#SBATCH --output=s.77834.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/alignment.77834.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/samtools.version
samtools merge -@2 /localhome/fpauler/77834.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77834.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77834.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77834.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77834.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77834.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/merging.log

mkfifo /localhome/fpauler/PIPE.77834
bamToFastq -i /localhome/fpauler/77834.merged.bam -fq /localhome/fpauler/PIPE.77834 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/samtofastq.77834.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/samtofastq.77834.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77834. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77834 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/STAR.77834.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/STAR.77834.log

cp -R /localhome/fpauler/STAR.77834.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77834/.
rm /localhome/fpauler/STAR.77834.* -r 
rm /localhome/fpauler/PIPE*77834
rm /localhome/fpauler/77834.merged.bam
