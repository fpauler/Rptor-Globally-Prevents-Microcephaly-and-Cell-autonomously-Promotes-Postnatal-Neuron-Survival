#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77843
#SBATCH --output=s.77843.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/alignment.77843.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/samtools.version
samtools merge -@2 /localhome/fpauler/77843.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77843.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77843.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77843.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77843.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77843.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/merging.log

mkfifo /localhome/fpauler/PIPE.77843
bamToFastq -i /localhome/fpauler/77843.merged.bam -fq /localhome/fpauler/PIPE.77843 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/samtofastq.77843.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/samtofastq.77843.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77843. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77843 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/STAR.77843.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/STAR.77843.log

cp -R /localhome/fpauler/STAR.77843.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77843/.
rm /localhome/fpauler/STAR.77843.* -r 
rm /localhome/fpauler/PIPE*77843
rm /localhome/fpauler/77843.merged.bam
