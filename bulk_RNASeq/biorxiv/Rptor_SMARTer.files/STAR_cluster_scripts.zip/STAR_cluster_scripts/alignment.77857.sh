#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77857
#SBATCH --output=s.77857.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/alignment.77857.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/samtools.version
samtools merge -@2 /localhome/fpauler/77857.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77857.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77857.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77857.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77857.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77857.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/merging.log

mkfifo /localhome/fpauler/PIPE.77857
bamToFastq -i /localhome/fpauler/77857.merged.bam -fq /localhome/fpauler/PIPE.77857 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/samtofastq.77857.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/samtofastq.77857.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77857. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77857 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/STAR.77857.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/STAR.77857.log

cp -R /localhome/fpauler/STAR.77857.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77857/.
rm /localhome/fpauler/STAR.77857.* -r 
rm /localhome/fpauler/PIPE*77857
rm /localhome/fpauler/77857.merged.bam
