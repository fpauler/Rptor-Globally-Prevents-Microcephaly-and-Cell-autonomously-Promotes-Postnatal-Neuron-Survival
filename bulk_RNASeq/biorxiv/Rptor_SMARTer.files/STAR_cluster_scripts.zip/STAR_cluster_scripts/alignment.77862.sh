#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77862
#SBATCH --output=s.77862.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/alignment.77862.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/samtools.version
samtools merge -@2 /localhome/fpauler/77862.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77862.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77862.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77862.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77862.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77862.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/merging.log

mkfifo /localhome/fpauler/PIPE.77862
bamToFastq -i /localhome/fpauler/77862.merged.bam -fq /localhome/fpauler/PIPE.77862 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/samtofastq.77862.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/samtofastq.77862.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77862. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77862 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/STAR.77862.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/STAR.77862.log

cp -R /localhome/fpauler/STAR.77862.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77862/.
rm /localhome/fpauler/STAR.77862.* -r 
rm /localhome/fpauler/PIPE*77862
rm /localhome/fpauler/77862.merged.bam
