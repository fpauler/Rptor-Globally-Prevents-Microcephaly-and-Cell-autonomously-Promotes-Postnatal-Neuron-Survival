#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77852
#SBATCH --output=s.77852.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/alignment.77852.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/samtools.version
samtools merge -@2 /localhome/fpauler/77852.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77852.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77852.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77852.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77852.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77852.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/merging.log

mkfifo /localhome/fpauler/PIPE.77852
bamToFastq -i /localhome/fpauler/77852.merged.bam -fq /localhome/fpauler/PIPE.77852 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/samtofastq.77852.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/samtofastq.77852.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77852. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77852 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/STAR.77852.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/STAR.77852.log

cp -R /localhome/fpauler/STAR.77852.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77852/.
rm /localhome/fpauler/STAR.77852.* -r 
rm /localhome/fpauler/PIPE*77852
rm /localhome/fpauler/77852.merged.bam
