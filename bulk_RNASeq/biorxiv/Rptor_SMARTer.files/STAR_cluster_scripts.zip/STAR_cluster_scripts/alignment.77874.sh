#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77874
#SBATCH --output=s.77874.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/alignment.77874.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/samtools.version
samtools merge -@2 /localhome/fpauler/77874.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77874.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77874.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77874.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77874.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77874.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/merging.log

mkfifo /localhome/fpauler/PIPE.77874
bamToFastq -i /localhome/fpauler/77874.merged.bam -fq /localhome/fpauler/PIPE.77874 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/samtofastq.77874.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/samtofastq.77874.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77874. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77874 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/STAR.77874.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/STAR.77874.log

cp -R /localhome/fpauler/STAR.77874.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77874/.
rm /localhome/fpauler/STAR.77874.* -r 
rm /localhome/fpauler/PIPE*77874
rm /localhome/fpauler/77874.merged.bam
