#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77844
#SBATCH --output=s.77844.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/alignment.77844.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/samtools.version
samtools merge -@2 /localhome/fpauler/77844.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77844.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77844.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77844.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77844.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77844.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/merging.log

mkfifo /localhome/fpauler/PIPE.77844
bamToFastq -i /localhome/fpauler/77844.merged.bam -fq /localhome/fpauler/PIPE.77844 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/samtofastq.77844.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/samtofastq.77844.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77844. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77844 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/STAR.77844.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/STAR.77844.log

cp -R /localhome/fpauler/STAR.77844.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77844/.
rm /localhome/fpauler/STAR.77844.* -r 
rm /localhome/fpauler/PIPE*77844
rm /localhome/fpauler/77844.merged.bam
