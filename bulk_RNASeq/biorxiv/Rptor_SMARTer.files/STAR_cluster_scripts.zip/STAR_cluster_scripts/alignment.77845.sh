#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77845
#SBATCH --output=s.77845.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/alignment.77845.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/samtools.version
samtools merge -@2 /localhome/fpauler/77845.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77845.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77845.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77845.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77845.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77845.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/merging.log

mkfifo /localhome/fpauler/PIPE.77845
bamToFastq -i /localhome/fpauler/77845.merged.bam -fq /localhome/fpauler/PIPE.77845 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/samtofastq.77845.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/samtofastq.77845.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77845. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77845 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/STAR.77845.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/STAR.77845.log

cp -R /localhome/fpauler/STAR.77845.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77845/.
rm /localhome/fpauler/STAR.77845.* -r 
rm /localhome/fpauler/PIPE*77845
rm /localhome/fpauler/77845.merged.bam
