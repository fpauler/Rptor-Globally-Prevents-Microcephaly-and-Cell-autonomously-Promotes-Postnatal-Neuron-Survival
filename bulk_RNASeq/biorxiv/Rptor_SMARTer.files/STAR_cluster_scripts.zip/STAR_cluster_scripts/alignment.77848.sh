#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77848
#SBATCH --output=s.77848.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/alignment.77848.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/samtools.version
samtools merge -@2 /localhome/fpauler/77848.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77848.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77848.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77848.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77848.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77848.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/merging.log

mkfifo /localhome/fpauler/PIPE.77848
bamToFastq -i /localhome/fpauler/77848.merged.bam -fq /localhome/fpauler/PIPE.77848 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/samtofastq.77848.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/samtofastq.77848.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77848. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77848 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/STAR.77848.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/STAR.77848.log

cp -R /localhome/fpauler/STAR.77848.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77848/.
rm /localhome/fpauler/STAR.77848.* -r 
rm /localhome/fpauler/PIPE*77848
rm /localhome/fpauler/77848.merged.bam
