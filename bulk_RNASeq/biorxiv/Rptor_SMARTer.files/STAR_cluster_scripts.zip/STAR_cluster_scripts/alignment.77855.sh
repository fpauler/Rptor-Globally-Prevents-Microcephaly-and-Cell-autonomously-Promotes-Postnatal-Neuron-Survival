#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77855
#SBATCH --output=s.77855.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/alignment.77855.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/samtools.version
samtools merge -@2 /localhome/fpauler/77855.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77855.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77855.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77855.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77855.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77855.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/merging.log

mkfifo /localhome/fpauler/PIPE.77855
bamToFastq -i /localhome/fpauler/77855.merged.bam -fq /localhome/fpauler/PIPE.77855 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/samtofastq.77855.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/samtofastq.77855.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77855. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77855 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/STAR.77855.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/STAR.77855.log

cp -R /localhome/fpauler/STAR.77855.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77855/.
rm /localhome/fpauler/STAR.77855.* -r 
rm /localhome/fpauler/PIPE*77855
rm /localhome/fpauler/77855.merged.bam
