#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77836
#SBATCH --output=s.77836.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/alignment.77836.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/samtools.version
samtools merge -@2 /localhome/fpauler/77836.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77836.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77836.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77836.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77836.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77836.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/merging.log

mkfifo /localhome/fpauler/PIPE.77836
bamToFastq -i /localhome/fpauler/77836.merged.bam -fq /localhome/fpauler/PIPE.77836 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/samtofastq.77836.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/samtofastq.77836.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77836. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77836 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/STAR.77836.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/STAR.77836.log

cp -R /localhome/fpauler/STAR.77836.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77836/.
rm /localhome/fpauler/STAR.77836.* -r 
rm /localhome/fpauler/PIPE*77836
rm /localhome/fpauler/77836.merged.bam
