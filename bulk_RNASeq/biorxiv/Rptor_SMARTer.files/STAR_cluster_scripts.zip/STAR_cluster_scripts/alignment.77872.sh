#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77872
#SBATCH --output=s.77872.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/alignment.77872.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/samtools.version
samtools merge -@2 /localhome/fpauler/77872.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77872.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77872.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77872.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77872.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77872.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/merging.log

mkfifo /localhome/fpauler/PIPE.77872
bamToFastq -i /localhome/fpauler/77872.merged.bam -fq /localhome/fpauler/PIPE.77872 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/samtofastq.77872.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/samtofastq.77872.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77872. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77872 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/STAR.77872.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/STAR.77872.log

cp -R /localhome/fpauler/STAR.77872.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77872/.
rm /localhome/fpauler/STAR.77872.* -r 
rm /localhome/fpauler/PIPE*77872
rm /localhome/fpauler/77872.merged.bam
