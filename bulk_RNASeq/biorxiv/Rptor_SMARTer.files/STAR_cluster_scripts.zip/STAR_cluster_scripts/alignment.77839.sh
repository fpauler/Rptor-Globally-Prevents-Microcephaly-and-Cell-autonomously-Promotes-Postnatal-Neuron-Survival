#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77839
#SBATCH --output=s.77839.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/alignment.77839.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/samtools.version
samtools merge -@2 /localhome/fpauler/77839.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77839.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77839.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77839.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77839.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77839.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/merging.log

mkfifo /localhome/fpauler/PIPE.77839
bamToFastq -i /localhome/fpauler/77839.merged.bam -fq /localhome/fpauler/PIPE.77839 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/samtofastq.77839.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/samtofastq.77839.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77839. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77839 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/STAR.77839.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/STAR.77839.log

cp -R /localhome/fpauler/STAR.77839.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77839/.
rm /localhome/fpauler/STAR.77839.* -r 
rm /localhome/fpauler/PIPE*77839
rm /localhome/fpauler/77839.merged.bam
