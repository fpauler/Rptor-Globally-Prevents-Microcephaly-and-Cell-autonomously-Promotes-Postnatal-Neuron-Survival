#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77861
#SBATCH --output=s.77861.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/alignment.77861.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/samtools.version
samtools merge -@2 /localhome/fpauler/77861.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77861.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77861.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77861.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77861.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77861.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/merging.log

mkfifo /localhome/fpauler/PIPE.77861
bamToFastq -i /localhome/fpauler/77861.merged.bam -fq /localhome/fpauler/PIPE.77861 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/samtofastq.77861.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/samtofastq.77861.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77861. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77861 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/STAR.77861.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/STAR.77861.log

cp -R /localhome/fpauler/STAR.77861.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77861/.
rm /localhome/fpauler/STAR.77861.* -r 
rm /localhome/fpauler/PIPE*77861
rm /localhome/fpauler/77861.merged.bam
