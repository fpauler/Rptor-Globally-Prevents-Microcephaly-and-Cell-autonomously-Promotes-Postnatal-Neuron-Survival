#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77867
#SBATCH --output=s.77867.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/alignment.77867.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/samtools.version
samtools merge -@2 /localhome/fpauler/77867.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77867.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77867.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77867.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77867.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77867.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/merging.log

mkfifo /localhome/fpauler/PIPE.77867
bamToFastq -i /localhome/fpauler/77867.merged.bam -fq /localhome/fpauler/PIPE.77867 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/samtofastq.77867.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/samtofastq.77867.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77867. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77867 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/STAR.77867.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/STAR.77867.log

cp -R /localhome/fpauler/STAR.77867.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77867/.
rm /localhome/fpauler/STAR.77867.* -r 
rm /localhome/fpauler/PIPE*77867
rm /localhome/fpauler/77867.merged.bam
