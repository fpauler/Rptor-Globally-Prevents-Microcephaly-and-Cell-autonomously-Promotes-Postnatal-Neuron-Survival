#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77863
#SBATCH --output=s.77863.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/alignment.77863.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/samtools.version
samtools merge -@2 /localhome/fpauler/77863.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77863.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77863.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77863.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77863.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77863.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/merging.log

mkfifo /localhome/fpauler/PIPE.77863
bamToFastq -i /localhome/fpauler/77863.merged.bam -fq /localhome/fpauler/PIPE.77863 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/samtofastq.77863.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/samtofastq.77863.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77863. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77863 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/STAR.77863.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/STAR.77863.log

cp -R /localhome/fpauler/STAR.77863.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77863/.
rm /localhome/fpauler/STAR.77863.* -r 
rm /localhome/fpauler/PIPE*77863
rm /localhome/fpauler/77863.merged.bam
