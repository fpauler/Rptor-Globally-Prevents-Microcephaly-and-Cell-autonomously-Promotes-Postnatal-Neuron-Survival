#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77841
#SBATCH --output=s.77841.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/alignment.77841.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/samtools.version
samtools merge -@2 /localhome/fpauler/77841.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77841.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77841.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77841.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77841.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77841.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/merging.log

mkfifo /localhome/fpauler/PIPE.77841
bamToFastq -i /localhome/fpauler/77841.merged.bam -fq /localhome/fpauler/PIPE.77841 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/samtofastq.77841.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/samtofastq.77841.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77841. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77841 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/STAR.77841.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/STAR.77841.log

cp -R /localhome/fpauler/STAR.77841.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77841/.
rm /localhome/fpauler/STAR.77841.* -r 
rm /localhome/fpauler/PIPE*77841
rm /localhome/fpauler/77841.merged.bam
