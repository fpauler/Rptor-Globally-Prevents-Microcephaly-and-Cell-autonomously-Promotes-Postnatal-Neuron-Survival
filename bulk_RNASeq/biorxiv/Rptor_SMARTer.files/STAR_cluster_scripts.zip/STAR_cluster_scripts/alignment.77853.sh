#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77853
#SBATCH --output=s.77853.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/alignment.77853.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/samtools.version
samtools merge -@2 /localhome/fpauler/77853.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77853.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77853.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77853.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77853.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77853.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/merging.log

mkfifo /localhome/fpauler/PIPE.77853
bamToFastq -i /localhome/fpauler/77853.merged.bam -fq /localhome/fpauler/PIPE.77853 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/samtofastq.77853.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/samtofastq.77853.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77853. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77853 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/STAR.77853.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/STAR.77853.log

cp -R /localhome/fpauler/STAR.77853.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77853/.
rm /localhome/fpauler/STAR.77853.* -r 
rm /localhome/fpauler/PIPE*77853
rm /localhome/fpauler/77853.merged.bam
