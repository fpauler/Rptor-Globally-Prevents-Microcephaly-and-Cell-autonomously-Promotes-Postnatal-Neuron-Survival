#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77838
#SBATCH --output=s.77838.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/alignment.77838.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/samtools.version
samtools merge -@2 /localhome/fpauler/77838.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77838.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77838.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77838.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77838.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77838.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/merging.log

mkfifo /localhome/fpauler/PIPE.77838
bamToFastq -i /localhome/fpauler/77838.merged.bam -fq /localhome/fpauler/PIPE.77838 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/samtofastq.77838.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/samtofastq.77838.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77838. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77838 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/STAR.77838.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/STAR.77838.log

cp -R /localhome/fpauler/STAR.77838.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77838/.
rm /localhome/fpauler/STAR.77838.* -r 
rm /localhome/fpauler/PIPE*77838
rm /localhome/fpauler/77838.merged.bam
