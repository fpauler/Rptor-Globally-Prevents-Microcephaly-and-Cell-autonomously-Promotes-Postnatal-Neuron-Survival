#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77873
#SBATCH --output=s.77873.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/alignment.77873.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/samtools.version
samtools merge -@2 /localhome/fpauler/77873.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77873.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77873.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77873.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77873.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77873.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/merging.log

mkfifo /localhome/fpauler/PIPE.77873
bamToFastq -i /localhome/fpauler/77873.merged.bam -fq /localhome/fpauler/PIPE.77873 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/samtofastq.77873.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/samtofastq.77873.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77873. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77873 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/STAR.77873.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/STAR.77873.log

cp -R /localhome/fpauler/STAR.77873.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77873/.
rm /localhome/fpauler/STAR.77873.* -r 
rm /localhome/fpauler/PIPE*77873
rm /localhome/fpauler/77873.merged.bam
