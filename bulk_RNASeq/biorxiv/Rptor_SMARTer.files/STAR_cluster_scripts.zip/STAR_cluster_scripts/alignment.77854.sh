#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77854
#SBATCH --output=s.77854.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/alignment.77854.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/samtools.version
samtools merge -@2 /localhome/fpauler/77854.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77854.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77854.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77854.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77854.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77854.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/merging.log

mkfifo /localhome/fpauler/PIPE.77854
bamToFastq -i /localhome/fpauler/77854.merged.bam -fq /localhome/fpauler/PIPE.77854 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/samtofastq.77854.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/samtofastq.77854.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77854. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77854 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/STAR.77854.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/STAR.77854.log

cp -R /localhome/fpauler/STAR.77854.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77854/.
rm /localhome/fpauler/STAR.77854.* -r 
rm /localhome/fpauler/PIPE*77854
rm /localhome/fpauler/77854.merged.bam
