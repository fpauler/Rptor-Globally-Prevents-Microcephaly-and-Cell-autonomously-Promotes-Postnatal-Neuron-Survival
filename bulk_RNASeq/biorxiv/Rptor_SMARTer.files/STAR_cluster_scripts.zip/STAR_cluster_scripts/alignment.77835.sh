#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77835
#SBATCH --output=s.77835.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/alignment.77835.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/samtools.version
samtools merge -@2 /localhome/fpauler/77835.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77835.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77835.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77835.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77835.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77835.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/merging.log

mkfifo /localhome/fpauler/PIPE.77835
bamToFastq -i /localhome/fpauler/77835.merged.bam -fq /localhome/fpauler/PIPE.77835 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/samtofastq.77835.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/samtofastq.77835.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77835. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77835 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/STAR.77835.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/STAR.77835.log

cp -R /localhome/fpauler/STAR.77835.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77835/.
rm /localhome/fpauler/STAR.77835.* -r 
rm /localhome/fpauler/PIPE*77835
rm /localhome/fpauler/77835.merged.bam
