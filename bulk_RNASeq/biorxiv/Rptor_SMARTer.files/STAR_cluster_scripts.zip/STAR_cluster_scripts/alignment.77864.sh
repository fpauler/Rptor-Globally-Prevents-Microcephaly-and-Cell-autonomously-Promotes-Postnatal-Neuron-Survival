#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77864
#SBATCH --output=s.77864.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/alignment.77864.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/samtools.version
samtools merge -@2 /localhome/fpauler/77864.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77864.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77864.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77864.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77864.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77864.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/merging.log

mkfifo /localhome/fpauler/PIPE.77864
bamToFastq -i /localhome/fpauler/77864.merged.bam -fq /localhome/fpauler/PIPE.77864 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/samtofastq.77864.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/samtofastq.77864.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77864. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77864 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/STAR.77864.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/STAR.77864.log

cp -R /localhome/fpauler/STAR.77864.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77864/.
rm /localhome/fpauler/STAR.77864.* -r 
rm /localhome/fpauler/PIPE*77864
rm /localhome/fpauler/77864.merged.bam
