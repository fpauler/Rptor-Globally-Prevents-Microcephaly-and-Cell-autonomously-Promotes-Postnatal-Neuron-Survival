#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77856
#SBATCH --output=s.77856.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/alignment.77856.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/samtools.version
samtools merge -@2 /localhome/fpauler/77856.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77856.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77856.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77856.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77856.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77856.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/merging.log

mkfifo /localhome/fpauler/PIPE.77856
bamToFastq -i /localhome/fpauler/77856.merged.bam -fq /localhome/fpauler/PIPE.77856 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/samtofastq.77856.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/samtofastq.77856.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77856. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77856 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/STAR.77856.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/STAR.77856.log

cp -R /localhome/fpauler/STAR.77856.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77856/.
rm /localhome/fpauler/STAR.77856.* -r 
rm /localhome/fpauler/PIPE*77856
rm /localhome/fpauler/77856.merged.bam
