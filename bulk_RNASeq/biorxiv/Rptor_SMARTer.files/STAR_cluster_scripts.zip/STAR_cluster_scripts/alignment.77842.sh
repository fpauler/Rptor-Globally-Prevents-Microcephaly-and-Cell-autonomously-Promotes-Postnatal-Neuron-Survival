#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77842
#SBATCH --output=s.77842.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/alignment.77842.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/samtools.version
samtools merge -@2 /localhome/fpauler/77842.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77842.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77842.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77842.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77842.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77842.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/merging.log

mkfifo /localhome/fpauler/PIPE.77842
bamToFastq -i /localhome/fpauler/77842.merged.bam -fq /localhome/fpauler/PIPE.77842 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/samtofastq.77842.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/samtofastq.77842.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77842. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77842 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/STAR.77842.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/STAR.77842.log

cp -R /localhome/fpauler/STAR.77842.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77842/.
rm /localhome/fpauler/STAR.77842.* -r 
rm /localhome/fpauler/PIPE*77842
rm /localhome/fpauler/77842.merged.bam
