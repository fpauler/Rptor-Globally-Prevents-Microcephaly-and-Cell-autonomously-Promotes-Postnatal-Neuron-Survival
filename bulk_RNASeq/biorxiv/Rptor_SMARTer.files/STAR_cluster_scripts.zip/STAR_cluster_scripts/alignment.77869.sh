#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77869
#SBATCH --output=s.77869.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/alignment.77869.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/samtools.version
samtools merge -@2 /localhome/fpauler/77869.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77869.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77869.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77869.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77869.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77869.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/merging.log

mkfifo /localhome/fpauler/PIPE.77869
bamToFastq -i /localhome/fpauler/77869.merged.bam -fq /localhome/fpauler/PIPE.77869 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/samtofastq.77869.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/samtofastq.77869.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77869. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77869 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/STAR.77869.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/STAR.77869.log

cp -R /localhome/fpauler/STAR.77869.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77869/.
rm /localhome/fpauler/STAR.77869.* -r 
rm /localhome/fpauler/PIPE*77869
rm /localhome/fpauler/77869.merged.bam
