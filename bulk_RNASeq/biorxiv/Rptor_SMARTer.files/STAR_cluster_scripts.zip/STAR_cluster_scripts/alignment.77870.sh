#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77870
#SBATCH --output=s.77870.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/alignment.77870.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/samtools.version
samtools merge -@2 /localhome/fpauler/77870.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77870.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77870.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77870.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77870.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77870.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/merging.log

mkfifo /localhome/fpauler/PIPE.77870
bamToFastq -i /localhome/fpauler/77870.merged.bam -fq /localhome/fpauler/PIPE.77870 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/samtofastq.77870.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/samtofastq.77870.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77870. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77870 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/STAR.77870.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/STAR.77870.log

cp -R /localhome/fpauler/STAR.77870.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77870/.
rm /localhome/fpauler/STAR.77870.* -r 
rm /localhome/fpauler/PIPE*77870
rm /localhome/fpauler/77870.merged.bam
