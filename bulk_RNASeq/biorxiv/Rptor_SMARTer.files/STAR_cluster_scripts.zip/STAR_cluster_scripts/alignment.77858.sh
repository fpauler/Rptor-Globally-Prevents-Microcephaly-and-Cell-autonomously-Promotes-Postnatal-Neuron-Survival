#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77858
#SBATCH --output=s.77858.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/alignment.77858.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/samtools.version
samtools merge -@2 /localhome/fpauler/77858.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77858.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77858.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77858.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77858.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77858.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/merging.log

mkfifo /localhome/fpauler/PIPE.77858
bamToFastq -i /localhome/fpauler/77858.merged.bam -fq /localhome/fpauler/PIPE.77858 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/samtofastq.77858.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/samtofastq.77858.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77858. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77858 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/STAR.77858.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/STAR.77858.log

cp -R /localhome/fpauler/STAR.77858.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77858/.
rm /localhome/fpauler/STAR.77858.* -r 
rm /localhome/fpauler/PIPE*77858
rm /localhome/fpauler/77858.merged.bam
