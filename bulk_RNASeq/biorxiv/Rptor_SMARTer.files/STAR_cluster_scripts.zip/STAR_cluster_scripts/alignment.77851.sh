#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77851
#SBATCH --output=s.77851.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/alignment.77851.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/samtools.version
samtools merge -@2 /localhome/fpauler/77851.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77851.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77851.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77851.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77851.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77851.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/merging.log

mkfifo /localhome/fpauler/PIPE.77851
bamToFastq -i /localhome/fpauler/77851.merged.bam -fq /localhome/fpauler/PIPE.77851 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/samtofastq.77851.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/samtofastq.77851.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77851. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77851 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/STAR.77851.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/STAR.77851.log

cp -R /localhome/fpauler/STAR.77851.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77851/.
rm /localhome/fpauler/STAR.77851.* -r 
rm /localhome/fpauler/PIPE*77851
rm /localhome/fpauler/77851.merged.bam
