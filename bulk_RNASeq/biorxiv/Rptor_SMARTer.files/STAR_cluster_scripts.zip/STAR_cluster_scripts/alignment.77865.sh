#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77865
#SBATCH --output=s.77865.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/alignment.77865.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/samtools.version
samtools merge -@2 /localhome/fpauler/77865.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77865.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77865.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77865.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77865.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77865.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/merging.log

mkfifo /localhome/fpauler/PIPE.77865
bamToFastq -i /localhome/fpauler/77865.merged.bam -fq /localhome/fpauler/PIPE.77865 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/samtofastq.77865.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/samtofastq.77865.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77865. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77865 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/STAR.77865.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/STAR.77865.log

cp -R /localhome/fpauler/STAR.77865.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77865/.
rm /localhome/fpauler/STAR.77865.* -r 
rm /localhome/fpauler/PIPE*77865
rm /localhome/fpauler/77865.merged.bam
