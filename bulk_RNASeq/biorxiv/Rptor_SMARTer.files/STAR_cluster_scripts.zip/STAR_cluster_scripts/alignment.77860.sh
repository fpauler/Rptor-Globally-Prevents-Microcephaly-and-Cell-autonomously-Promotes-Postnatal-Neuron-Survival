#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77860
#SBATCH --output=s.77860.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/alignment.77860.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/samtools.version
samtools merge -@2 /localhome/fpauler/77860.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77860.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77860.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77860.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77860.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77860.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/merging.log

mkfifo /localhome/fpauler/PIPE.77860
bamToFastq -i /localhome/fpauler/77860.merged.bam -fq /localhome/fpauler/PIPE.77860 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/samtofastq.77860.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/samtofastq.77860.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77860. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77860 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/STAR.77860.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/STAR.77860.log

cp -R /localhome/fpauler/STAR.77860.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77860/.
rm /localhome/fpauler/STAR.77860.* -r 
rm /localhome/fpauler/PIPE*77860
rm /localhome/fpauler/77860.merged.bam
