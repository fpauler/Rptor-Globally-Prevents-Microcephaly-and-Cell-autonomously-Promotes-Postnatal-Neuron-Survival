#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77840
#SBATCH --output=s.77840.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/alignment.77840.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/samtools.version
samtools merge -@2 /localhome/fpauler/77840.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77840.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77840.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77840.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77840.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77840.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/merging.log

mkfifo /localhome/fpauler/PIPE.77840
bamToFastq -i /localhome/fpauler/77840.merged.bam -fq /localhome/fpauler/PIPE.77840 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/samtofastq.77840.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/samtofastq.77840.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77840. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77840 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/STAR.77840.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/STAR.77840.log

cp -R /localhome/fpauler/STAR.77840.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77840/.
rm /localhome/fpauler/STAR.77840.* -r 
rm /localhome/fpauler/PIPE*77840
rm /localhome/fpauler/77840.merged.bam
