#!/bin/bash
#SBATCH --ntasks=3
#SBATCH --job-name=s.77849
#SBATCH --output=s.77849.out
#SBATCH --time=10:00:00
#SBATCH --mem=30G
#SBATCH --no-requeue
module load samtools
mkdir /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849
echo $(date) $(hostname) > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/alignment.77849.job.log
module load samtools

samtools --version > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/samtools.version
samtools merge -@2 /localhome/fpauler/77849.merged.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77849.1.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77849.2.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77849.3.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77849.4.bam /nfs/scistore12/hippegrp/fpauler/bam_files/raw_BAM_files/77849.5.bam 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/merging.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/merging.log

mkfifo /localhome/fpauler/PIPE.77849
bamToFastq -i /localhome/fpauler/77849.merged.bam -fq /localhome/fpauler/PIPE.77849 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/samtofastq.77849.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/samtofastq.77849.log &

/nfs/scistore12/hippegrp/fpauler/programs/STAR/STAR --genomeLoad NoSharedMemory --outFilterMultimapNmax 1 --outSAMstrandField intronMotif --outFilterIntronMotifs RemoveNoncanonical \
	     --runThreadN 2 --outSAMtype BAM SortedByCoordinate --limitBAMsortRAM 3000000000 --quantMode GeneCounts \
	     --outFileNamePrefix /localhome/fpauler/STAR.77849. \
             --genomeDir /nfs/scistore12/hippegrp/fpauler/STAR_index_with_M16/ \
             --readFilesIn /localhome/fpauler/PIPE.77849 2> /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/STAR.77849.err > /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/STAR.77849.log

cp -R /localhome/fpauler/STAR.77849.* /nfs/scistore12/hippegrp/fpauler/bam_files/alignment.77849/.
rm /localhome/fpauler/STAR.77849.* -r 
rm /localhome/fpauler/PIPE*77849
rm /localhome/fpauler/77849.merged.bam
